(function() {
  window.App || (window.App = {});

  App.init = function() {};

  $(document).on("DOMContentLoaded", function() {
    return App.init();
  });

}).call(this);
